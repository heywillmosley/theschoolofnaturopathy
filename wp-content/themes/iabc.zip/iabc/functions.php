<?php

// Defines
define('FL_CHILD_THEME_DIR', get_stylesheet_directory());
define('FL_CHILD_THEME_URL', get_stylesheet_directory_uri());

/* Load custom login page styles */
function my_custom_login() {
echo '<link rel="stylesheet" type="text/css" href="' . get_bloginfo('stylesheet_directory') . '/login/custom-login-styles.css" />';
}
add_action('login_head', 'my_custom_login');

// Classes
require_once 'classes/FLChildTheme.php';


// Actions
add_action('fl_head', 'FLChildTheme::stylesheet');

/* Custom redirect after login to homepage */
function login_redirect( $redirect_to, $request, $user ){
    return home_url('/');
}
add_filter( 'login_redirect', 'login_redirect', 10, 3 );

add_action('wp_head', 'display_zd_logged_in');
function display_zd_logged_in(){

	if (is_user_logged_in()) { ?>

	<!-- Start of newhuman1 Zendesk Widget script -->
	<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=2a88c7d2-77bc-44e5-9925-e63fa468ad46"> </script>

	<?php };

} // end function display_zd_logged_in()


if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page();
	
}

// Custom Portrait Size
add_theme_support( 'post-thumbnails' );
add_image_size( 'portrait', 340, 485, true );